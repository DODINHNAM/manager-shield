<?php require_once __DIR__ . '/../layout_header.php'; ?>
<h3>Admin Dashboard</h3>
<div class="row">
  <div class="col-md-6">
    <a href="index.php?action=admin_webshields" class="btn btn-outline-primary">Quản lý Web Shields</a>
  </div>
  <div class="col-md-6">
    <a href="index.php?action=admin_users" class="btn btn-outline-primary">Quản lý Users</a>
  </div>
</div>
<?php require_once __DIR__ . '/../layout_footer.php'; ?>
