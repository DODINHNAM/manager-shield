
    </section>

    <footer class="footer">
      <p>© <?= date('Y') ?> Cards Shield. All rights reserved.</p>
    </footer>
  </main>
</div>
<script src="/assets/js/core.js"></script>
</body>
</html>
