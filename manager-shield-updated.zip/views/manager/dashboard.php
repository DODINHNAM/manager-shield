<?php require_once __DIR__ . '/../layout_header.php'; ?>
<h3>Manager Dashboard</h3>
<div class="row">
    <div class="col-md-6">
        <a href="index.php?action=manager_my_webshields" class="btn btn-outline-primary">Xem Web Shields của tôi</a>
    </div>
    <div class="col-md-6">
        <a href="index.php?action=manager_whitelist">Whitelist domain</a>
    </div>
</div>
<?php require_once __DIR__ . '/../layout_footer.php'; ?>
