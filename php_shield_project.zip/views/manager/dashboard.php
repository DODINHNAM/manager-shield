<?php require_once __DIR__ . '/../layout_header.php'; ?>
<h3>Manager Dashboard</h3>
<p><a href="index.php?action=manager_my_webshields" class="btn btn-outline-primary">Xem Web Shields của tôi</a></p>
<?php require_once __DIR__ . '/../layout_footer.php'; ?>
